<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JOINT MOVERS </title>
    <link rel="stylesheet" href="Joint.css">
    <link rel="stylesheet" href="responsive.css">

</head>
<body>
    <header>
        <!-- header start -->
        <div class="company-name"> 
            <div><img class="logo" src="Joints/logo.jpg" ></div>
            <h1  style="margin-left: 30px;">JOINT MOVERS KENYA</h1>
            <li style="margin-left: 600px;color: blue;"><a href="login.php"> <b> Login</b></a></li>
        </div>
    </header>
    <!-- header end -->
    <!-- section start -->
    <Section class="header">
         <!-- nav start -->
         <nav>
               
            <div class="primary-nav">
             <ul class="nav">

             <li><a href="index.php"><b>HOME</b></a></li>
             <li><a href="About us.php"><b>ABOUT US</b></a></li>
             <li><a href="Services.php"><b>SERVICES</b></a></li>
               <!-- poject logo start -->
            <div>
             <img class="logo" src="Joints/logo.jpg">

            </div> 
            <!-- project logo end -->
             <li><a href="Moving Price.php"><b>MOVING PRICE</b></a></li>
             <li><a href="Blog.php"><b>BLOG</b></a></li>
             <li><a href="Contacts.php"><b>CONTACTS</b></a></li>
 
 
         </ul>
         </div>
         
 </nav> 
 <h2 style="text-align: center;">BLOG</h2>
 </section>
 <section>
    <p style="color: brown;">
        <h3>
            Welcome to Joint Movers, your trusted partner in seamless relocations and comprehensive moving services within Nairobi. Whether <br>
        you're planning a house move, office relocation, or require efficient warehousing solutions, Joint Movers is here to make your transition <br>
        smooth and stress-free. Additionally, we offer specialized services like TV mounting and DSTV installation, ensuring that every aspect of your move is handled with expertise and care.
        </h3>
    </p>
 </section>
 <section class="blogsn1" style="display: flex; flex-direction: row;">

    <div class="blog1">
        <img src="Joints/home.jpg" alt="">
        <b>House Moving:</b> Moving to a new home can be both exciting and daunting. At Joint Movers, we understand the importance of ensuring that your <br>
        belongings are transported safely and securely. Our experienced team is equipped to handle all aspects of your house move, from packing and loading <br>
        to transportation and unpacking. With our attention to detail and commitment to excellence, you can trust us to make your house move a breeze.
    </div>
    <div class="blog2" style="margin-left: 100px;">
        <img src="Joints/office.jpg" alt="">
        <b>Office Relocation: </b>Planning an office relocation? Let Joint Movers take the stress out of the process. We specialize in office relocations of all sizes, ensuring <br>
         minimal disruption to your business operations. Our team works efficiently to pack and transport your office furniture, equipment, and documents, allowing you to focus <br>
         on what matters most – your business. With our strategic approach and careful planning, you can count on us to deliver a seamless office relocation experience.
    </div> 
 </section>
 <section class="blogsn2" style="display: flex; flex-direction: row;">
    <div class="blog3">
        <img src="Joints/warehouse.jpg" alt="">
       <b>WAREHOUSING:</b> Need a safe and secure space to store your belongings? Joint Movers offers comprehensive warehousing solutions tailored to your needs. Whether you require short-term storage <br>
        during a move or long-term storage for excess inventory, we've got you covered. Our state-of-the-art warehouse facilities are equipped with advanced security measures to ensure the <br>
        safety of your items. With flexible storage options and competitive rates, Joint Movers is your trusted partner for all your warehousing needs.
    </div>
    <div class="blog4" style="margin-left: 70px;">
        <img src="Joints/tv.jpg" alt="">
        <b>TV Mounting: </b>Transform your living space with professional TV mounting services from Joint Movers. Our skilled technicians will ensure that your TV is securely mounted to <br>
        the wall, providing you with the perfect viewing angle and enhancing the aesthetics of your home. Whether you're looking to mount a flat-screen TV in your living room or install <br>
        a projector in your home theater, we have the expertise to bring your vision to life.
    </div>
    <div class="blog5"> 
         <img src="Joints/dstv.jpg" alt="" style="margin-right:230px ;">
        <b>DSTV Installation:</b> Enjoy seamless entertainment with DSTV installation services from Joint Movers. Our experienced technicians will handle all aspects of the installation process, from <br>
        satellite dish positioning to decoder setup. Whether you're upgrading your existing DSTV system or setting up a new subscription, we'll ensure that you get the best possible reception and <br>
        channel selection. With our prompt and professional service, you can start enjoying your favorite shows in no time.
</div>
</section>
 <!-- nav end -->
 <section class="blocks">
    <div>
        <h4> <strong>About U</strong></h4>
        <p>JOINTT Movers kenya offfers you unparalleled <br> service build on trust and backed at every level by <br>
            professional and experienced personnel.our high profile <br> credentials are built on provinging a professional, efficient <br>
             and cost effective.</p>
    </div>
    <div style="margin-left: 150px;">
        <h4><strong>Our Locatio</strong></h4>
        <b> Location: </b><br>
        <p>Nairobi kenya</p>

    </div>
    <div style="margin-left: 250px;">
        <h4>Contact Us</h4>
        <p>
            <b> Telephone/EMAIL:</b> <br>
            +254797641465  <br>
            jointkenyamovers@gmail.com
         </p>    
    </div>
</section>
    <!-- section end-->
    <footer>
        <div style="margin-right: 5px;">
            <img class="logo" src="Joints/logo.jpg" alt="">
        </div>
        <div>
            <h3>JOINT MOVERS</h3>
            <p>We Understand That Every Move Starts With A Detailed Assessment Of Your Requirements And Nature Of Your Goods</p>
        </div>
    </footer>
</body>
</html>