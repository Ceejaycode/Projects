<?php
include("connection.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <link rel="stylesheet" href="style.css">
    <script defer src="scrip.js"></script>
    <link rel="stylesheet" href="responsive.css">

</head>

<body>
    <div class="container">
        <h2>Sign Up</h2>
        <form action="" method="POST">
            <input type="text" name="user" placeholder="Full Name" required>
            <input type="email" name="email" placeholder="Email Address" required>
            <input type="password" name="pass" placeholder="Password" required>
            <input type="password" name="cpass" placeholder="Confirm Password" required>
            <input type="submit" id="btn" value="Sign Up" name="submit">
        </form>
    </div>
</body>

</html>

<?php
if(isset($_POST['submit'])){
    $username = $_POST['user'];
    $email = $_POST['email'];
    $password = $_POST['pass'];
    $cpassword = $_POST['cpass'];

    $sql_check = "SELECT * FROM signup WHERE username = '$username'";
    $result_check = mysqli_query($conn, $sql_check);
    $count_user = mysqli_num_rows($result_check);

    $sql_check = "SELECT * FROM signup WHERE email = '$email'";
    $result_check = mysqli_query($conn, $sql_check);
    $count_email = mysqli_num_rows($result_check);

    if($count_user == 0 && $count_email == 0){
        if($password == $cpassword){
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $sql = "INSERT INTO signup (username, email, password) VALUES('$username', '$email','$hash')";
            $result = mysqli_query($conn, $sql);
            if($result){
                mysqli_close($conn);
                header("location:login.php");
            }
            else{
                echo "Error: ". $sql. "<br>". mysqli_error($conn);
            }
        }
        else{
            echo '<script>
            alert("password do not match");
            window.location.href = "Signup_page.php";
            </script>';
        }
    }
    else{
        if($count_user > 0){
            echo '<script>
            window.location.href="Signup_page.php";
            alert("username already exists!!");
            </script>';
        }
        if($count_email > 0){
            echo '<script>
            window.location.href="Signup_page.php";
            alert("email already exists!!");
            </script>';
        }
    }
}
?>
