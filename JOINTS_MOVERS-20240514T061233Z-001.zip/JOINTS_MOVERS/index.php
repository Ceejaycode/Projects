<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JOINT MOVERS </title>
    <link rel="stylesheet" href="Joint.css">
    <link rel="stylesheet" href="responsive.css">
</head>
<body>
    <header>
        <div class="company-name"> 
            <div><img class="logo" src="Joints/logo.jpg" ></div>
        <h1  style="margin-left: 30px;color:red;">JOINT MOVERS KENYA</h1>
            <li style="margin-left: 600px;color: blue;"><a href="login.php"> <b> Login</b></a></li>
    </div>        
    
    </header>
    <!-- section start -->
    <Section class="header">
         <!--nav start -->
         <nav>
               
            <div class="primary-nav">
             <ul class="nav">

             <li><a href="index.php"><b>HOME</b></a></li>
             <li><a href="About us.php"><b>ABOUT US</b></a></li>
             <li><a href="Services.php"><b>SERVICES</b></a></li>
               <!-- poject logo start -->
            <div>
             <img class="logo" src="Joints/logo.jpg">

            </div> 
            <!-- project logo end -->
             <li><a href="Moving Price.php"><b>MOVING PRICE</b></a></li>
             <li><a href="Blog.php"><b>BLOG</b></a></li>
             <li><a href="Contacts.php"><b>CONTACTS</b></a></li>
 
         </ul>
         </div>
         
  </nav> 
         <h2 style="text-align: center;">HOME</h2>
</Section>
    <section class="body">
        <div class="home-img"><img src="Joints/movers.jpg" alt=""></div>
        <div style=" margin-left: 50px;">
         <p style="color: red; font-weight: bold; font-size: xx-large;float: left;">Welcome to JOINT MOVERS
            Your Trusted Moving Company in Kenya.
            We Move you without stress</p>
            <p> JOINT Movers kenya is a local owned moving service company in Nairobi kenya, which has <br> established a reputation foe excellence with friendly and personalized moving services in kenya
            </p>
        
            </div>
    </section>
    <section class="customer-care">
        <div>
            <h3>PROMISES</h3>
            <i>
                <p style="color:black;" >
                    We know that moving is very personal experience that requires understanding of your needs. That’s why we developed The JOINT <br>
                    
                    Mover, a removals methodology built around this philosophy.

                    Every move starts with a detailed assessment of your requirements and the <br>

                    nature of goods at hand. This informs the way we pack and handle each category of goods to ensure their integrity is maintained. Experience the delight of having breakfast<br> 
                    
                    at your old house, and by evening, enjoying dinner with feet up at your new house, all without breaking a sweat! We also offer affordable warehousing solutions.</p>
            

            </i>
            </div>

    </section>
    <section class="view">
        <div>
            <h4><strong>Feel Free To Request A Free Quote</strong></h4>
            <P style="color: goldenrod;"><Strong>
                JOINT Movers Kenya Moving consultants are trained to provide you with the very best advice and service from the moment you first make contact with us.<br>
                
                We provide you with a clear, unambiguous price quote with no hidden charges.<br>
                
                Finally, we will coordinate every aspect of your move and keep you posted each step of the way.<br>
                
                JOINT Movers Kenya commitment to quality and security means that we only use company-trained staff for our packing and removal services.</Strong></P>
        </div>
        <div class="Quote-button">
            <button><a href="Quote.html">REQUEST QUOTE</a></button>

        </div>
    </section>

 </section>
 <section class="blocks">
    <div>
        <h4> <strong>About U</strong></h4>
        <p>JOINTT Movers kenya offfers you unparalleled <br> service build on trust and backed at every level by <br>
            professional and experienced personnel.our high profile <br> credentials are built on provinging a professional, efficient <br>
             and cost effective.</p>
    </div>
    <div style="margin-left: 150px;">
        <h4><strong>Our Locatio</strong></h4>
        <b> Location: </b><br>
        <p>Nairobi kenya</p>

    </div>
    <div style="margin-left: 250px;">
        <h4>Contact Us</h4>
        <p>
            <b> Telephone/EMAIL:</b> <br>
            +254797641465  <br>
            jointkenyamovers@gmail.com
         </p>    
    </div>
</section>
    
    <!-- section end-->
    <footer>
            <div style="margin-right: 5px;">
                <img class="logo" src="Joints/logo.jpg" alt="">
            </div>
            <div>
                <h3>JOINT MOVERS</h3>
                <p>We Understand That Every Move Starts With A Detailed Assessment Of Your Requirements And Nature Of Your Goods</p>
            </div>
    </footer>
</body>
</html>