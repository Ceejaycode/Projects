<?php

session_start();

$con = mysqli_connect("localhost", "root", "", "users");

// Checking connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

// Set the time zone to your specific region
date_default_timezone_set('Africa/Nairobi');

// Retrieve tasks close to due date and priority levels for the specific user
$query = "SELECT * FROM quote";
$result = mysqli_query($con, $query);

// Check if the query was successful
if ($result === false) {
    die(mysqli_error($con));
}

// Loop through tasks
while ($row = mysqli_fetch_assoc($result)) {

    $mail = new PHPMailer(true);

    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'amosk5132@gmail.com'; //  Gmail address
    $mail->Password   = 'gbsw bvnx rnod xkar';    //  App Password
    $mail->SMTPSecure = 'tls';
    $mail->Port       = 587;

    $mail->setFrom('amosk5132@gmail.com', 'To Do List');
    $mail->addAddress($row['email']); // Corrected email address variable

    $mail->isHTML(true);
    $mail->Subject = 'To Do List Task Reminder';


    // Dynamic content in email body
    if (isset($row['name']) && isset($row['num']) && isset($row['email']) && isset($row['phone_no']) && isset($row['house_size']) && isset($row['moving_from']) 
        && isset($row['moving_to']) && isset($row['services']) && isset($row['date'] ) && isset($row['dstv']) && isset($row['tv_mounting'])) {
        $dynamicContent = "
        <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <style>
        body {
            font-family: 'Arial', sans-serif;
            line-height: 1.6;
            margin: 20px;
            background-color: #f8f8f8;
        }
        
        h1 {
            color: #3498db;
            text-align: center;
            margin-top: 20px;
        }
        
        p {
            color: #555;
            font-size: 16px;
            margin-bottom: 10px;
        }
        </style>
        </head>
        <body>
        <h1> Quote Request</h1>
        <p>Hello, you have received a new quote request,</p>
        <p>Here are the details:</p>
        <ul>
            <li><strong>Request number:</strong> {$row['num']}</li>
            <li><strong>Name:</strong> {$row['name']}</li>
            <li><strong>Email:</strong> {$row['email']}</li>
            <li><strong>Phone number:</strong> {$row['phone_no']}</li>
            <li><strong>House size:</strong> {$row['house_size']}</li>
            <li><strong>Moving from:</strong> {$row['moving_from']}</li>
            <li><strong>Moving to:</strong> {$row['moving_to']}</li>
            <li><strong>Services requested:</strong> {$row['services']}</li>
            <li><strong>Date of move:</strong> {$row['date']}</li>
            <li><strong>DSTV installation:</strong> {$row['dstv']}</li>
            <li><strong>TV mounting:</strong> {$row['tv_mounting']}</li>
        </ul>
        </body>";

        $mail->Body = $dynamicContent;

        try {
            // Attempt to send the email
            if ($mail->send()) {
                echo 'Email sent successfully.';

                // Update the last email sent timestamp in the database

            } else {
                echo 'Email sending failed.';
            }
        } catch (Exception $e) {
            echo "Email sending failed. Error: {$mail->ErrorInfo}";
        }
    }
}

// Close database connection
mysqli_close($con);
?>
