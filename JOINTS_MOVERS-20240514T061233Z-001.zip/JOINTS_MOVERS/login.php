<?php
include("connection.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link rel="stylesheet" href="login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="responsive.css">
    <script src="Authors.js"></script>
</head>

<body>

    <div class="wrapper">
        <header>Welcome to Joint movers <br>Login Form</header>
        <form action="" onsubmit="return invalid()" method="POST">
            <div class="field email">
                <div class="input-area">
                    <input type="text" name="user" placeholder="Username">
                    <i class="icon fas fa-envelope"></i>
                    <i class="error error-icon fas fa-exclamation-circle"></i>
                </div>
                <div class="error error-txt">Username can't be blank</div>
            </div>
            <div class="field password">
                <div class="input-area">
                    <input type="password" name="pass" placeholder="Password">
                    <i class="icon fas fa-lock"></i>
                    <i class="error error-icon fas fa-exclamation-circle"></i>
                </div>
                <div class="error error-txt">Password can't be blank</div>
            </div>
            <div class="pass-txt"><a href="#">Forgot password?</a></div>
            <input type="submit" value="Login" name="submit"/>

        </form>
        <div class="sign-txt">Not yet member? <a href="Signup_page.php">Signup now</a></div>
    </div>

    <script src="script.js"></script>

</body>

</html>

<?php
@session_start();
if(isset($_POST['submit'])){
    $username = $_POST["user"];
    $password = $_POST["pass"];

    $sql = "SELECT * FROM signup WHERE username = '$username'";
    $result = mysqli_query($conn, $sql);
    $count = mysqli_num_rows($result);
    $row = mysqli_fetch_array($result);
    
    // if($row["usertype"]=="user"){
    //     echo "user";
    // }
    // elseif($row["usertype"]=="admin"){
    //     echo "admin";
    // }
    // else{
    //     echo "username or password incorrect";
    // }
    

    if($row>0){
        $_SESSION['username']=$username;
        if(password_verify($password,$row['pass'])){
                $_SESSION['username']=$username;
          echo "<script>alert('login success')</script>";
          echo "<script>window.open('../index.php','_self')</script>";
        }else{
                $_SESSION['username']=$username;
                echo "<script>alert('login success')</script>";
                echo "<script>window.open('index.php','_self')</script>"; 
            }
        }else{
        echo "<script>alert('Invalid Credentials')</script>";  
        echo "<script>window.open('signup_page.php','_self')</script>"; 
        }
    }
?>