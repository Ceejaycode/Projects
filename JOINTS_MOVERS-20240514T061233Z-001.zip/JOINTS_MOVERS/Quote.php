<?php
include("connection.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JOINT MOVERS </title>
    <link rel="stylesheet" href="Joint.css">
    <link rel="stylesheet" href="responsive.css">
    <script defer src="scripts.js"></script>

</head>
<body>
    <header>
        <!-- haeder start -->
        <div class="company-name"> 
            <div><img class="logo" src="Joints/logo.jpg" ></div>
            <h1  style="margin-left: 30px;">JOINT MOVERS KENYA</h1>
            <li style="margin-left: 600px;color: blue;"><a href="login.html"> <b> Login</b></a></li>
    </div>
        
       

    </header>
    <!-- header end -->
    <!-- section start -->
    <Section class="header">
         <!-- nav start -->
         <nav>
               
            <div class="primary-nav">
             <ul class="nav">

             <li><a href="index.php"><b>HOME</b></a></li>
             <li><a href="About us.php"><b>ABOUT US</b></a></li>
             <li><a href="Services.php"><b>SERVICES</b></a></li>
               <!-- poject logo start -->
            <div>
             <img class="logo" src="Joints/logo.jpg">

            </div> 
            <!-- project logo end -->
             <li><a href="Moving Price.php"><b>MOVING PRICE</b></a></li>
             <li><a href="Blog.php"><b>BLOG</b></a></li>
             <li><a href="Contacts.php"><b>CONTACTS</b></a></li>
 
 
         </ul>
         </div>
         
 </nav> 
 <h2 style="text-align: center;">QUOTE</h2>
</section>
 <!-- nav end -->
    <section class="body" >
        <img src="Joints/van.jpg" alt="">
        <form style="margin-left: 70px;"  action="" method="POST" >
            <table>
                <tr>
                    <td><input type="text" placeholder="Name" name="name"></td>
                    <td><input type="text" placeholder="Email" name="email"></td>
                </tr>
                <tr>
                    <td> <input type="text" placeholder="Phone no" name="number" ></td>
                    <td> <input type="text" placeholder="House Size" name="house_size" > </td>
                </tr>
                <tr>
                    <td> <input type="text" placeholder="Moving From" name= "moving_from"> </td>
                    <td> <input type="text" placeholder="Moving To" name="moving_to"> </td>
                </tr>
                <tr>
                    <td>
                        <select name="service">
                            <option>House Moving</option>
                            <option>Office Relocation</option>
                            <option>Warehousing</option>
                        </select>
                    </td>
                    <td> <input type="date" placeholder="Moving Date" name="date"> </td>
                </tr>
                <tr>
                    <td> 
                        <input type="checkbox" id="tv_mounting" name="tv_mounting" value="Tv Mounting">
                        <label for="tv_mounting">Tv Mounting</label><br>
                        <input type="checkbox" id="dstv" name="dstv" value="DST installation">
                        <label for="dstv">DST installation</label><br>
                    </td>
                </tr>
                <tr>
                    <td><button type="submit" name="submit_details">SUBMIT</button> </td>
                </tr>
            </table>
        </form>

<?php

session_start();

$con = mysqli_connect("localhost", "root", "", "users");

// Checking connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'email_sender/vendor/autoload.php';

// Set the time zone to your specific region
date_default_timezone_set('Africa/Nairobi');

// Retrieve tasks close to due date and priority levels for the specific user
$query = "SELECT * FROM quote LIMIT 1";
$result = mysqli_query($con, $query);

// Check if the query was successful
if ($result === false) {
    die(mysqli_error($con));
}

// Loop through tasks
while ($row = mysqli_fetch_assoc($result)) {

    $mail = new PHPMailer(true);

    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'mashrodgers7@gmail.com'; //  Gmail address
    $mail->Password   = 'rnql chvw nxiv yyid';    //  App Password
    $mail->SMTPSecure = 'tls';
    $mail->Port       = 587;

    $mail->setFrom('mashrodgers7@gmail.com', 'Joint Movers');
    $mail->addAddress('mashrodgers7@gmail.com'); // Corrected email address variable

    $mail->isHTML(true);
    $mail->Subject = 'Quote Request';

    // Dynamic content in email body
    if (isset($row['name']) && isset($row['num']) && isset($row['email']) && isset($row['phone_no']) && isset($row['house_size']) && isset($row['moving_from']) 
        && isset($row['moving_to']) && isset($row['services']) && isset($row['date'] ) && isset($row['dstv']) && isset($row['tv_mounting'])) {
        $dynamicContent = "
        <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <style>
        body {
            font-family: 'Arial', sans-serif;
            line-height: 1.6;
            margin: 20px;
            background-color: #f8f8f8;
        }
        
        h1 {
            color: #3498db;
            text-align: center;
            margin-top: 20px;
        }
        
        p {
            color: #555;
            font-size: 16px;
            margin-bottom: 10px;
        }
        </style>
        </head>
        <body>
        <h1> Quote Request</h1>
        <p>Hello, you have received a new quote request,</p>
        <p>Here are the details:</p>
        <ul>
            <li><strong>Request number:</strong> {$row['num']}</li>
            <li><strong>Name:</strong> {$row['name']}</li>
            <li><strong>Email:</strong> {$row['email']}</li>
            <li><strong>Phone number:</strong> {$row['phone_no']}</li>
            <li><strong>House size:</strong> {$row['house_size']}</li>
            <li><strong>Moving from:</strong> {$row['moving_from']}</li>
            <li><strong>Moving to:</strong> {$row['moving_to']}</li>
            <li><strong>Services requested:</strong> {$row['services']}</li>
            <li><strong>Date of move:</strong> {$row['date']}</li>
            <li><strong>DSTV installation:</strong> {$row['dstv']}</li>
            <li><strong>TV mounting:</strong> {$row['tv_mounting']}</li>
        </ul>
        </body>";

        $mail->Body = $dynamicContent;

        try {
            // Attempt to send the email
            if ($mail->send()) {
                echo "<script>alert('Email sent successfully')</script>";

                // Update the last email sent timestamp in the database

            } else {
                echo "<script>alert('Email sending failed.')</script>";
            }
        } catch (Exception $e) {
            echo "Email sending failed. Error: {$mail->ErrorInfo}";
        }
    }
}

// Close database connection
mysqli_close($con);
?>

                </div>
            </section>
    <section class="blocks">
        <div>
            <h4> <strong>About U</strong></h4>
            <p>JOINTT Movers kenya offfers you unparalleled <br> service build on trust and backed at every level by <br>
                professional and experienced personnel.our high profile <br> credentials are built on provinging a professional, efficient <br>
                 and cost effective.</p>
        </div>
        <div style="margin-left: 150px;">
            <h4><strong>Our Locatio</strong></h4>
            <b> Location: </b><br>
            <p>Nairobi kenya</p>
    
        </div>
        <div style="margin-left: 250px;">
            <h4>Contact Us</h4>
            <p>
                <b> Telephone/EMAIL:</b> <br>
                +254797641465  <br>
                jointkenyamovers@gmail.com
             </p>    
        </div>
    </section>
        
    <!-- section end-->
    <footer>
        <div style="margin-right: 5px;">
            <img class="logo" src="Joints/logo.jpg" alt="">
        </div>
        <div>
            <h3>JOINT MOVERS</h3>
            <p>We Understand That Every Move Starts With A Detailed Assessment Of Your Requirements And Nature Of Your Goods</p>
        </div>
</body>
</html>

<?php
if(isset($_POST['submit_details'])){
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $number = mysqli_real_escape_string($conn, $_POST['number']);
    $house_size = mysqli_real_escape_string($conn, $_POST['house_size']);
    $moving_from = mysqli_real_escape_string($conn, $_POST['moving_from']);
    $moving_to = mysqli_real_escape_string($conn, $_POST['moving_to']);
    $service = mysqli_real_escape_string($conn, $_POST['service']);
    $date = mysqli_real_escape_string($conn, $_POST['date']);
    $dstv = mysqli_real_escape_string($conn, $_POST['dstv']);
    $tv_mounting = mysqli_real_escape_string($conn, $_POST['tv_mounting']);

    //checking empty condition
    if(empty($name) || empty($email) || empty($number) || empty($house_size) || empty($moving_from) || empty($moving_to) || empty($service) || empty($date)){
        echo "<script>alert('please fill all fields')</script>";
        exit();
    } else {
        //insert query
        $insert_details = "INSERT INTO quote (name,email,phone_no,house_size,moving_from,moving_to,services,date,dstv,tv_mounting) VALUES ('$name', '$email', '$number', '$house_size', '$moving_from', '$moving_to', '$service', '$date', '$dstv','$tv_mounting')";
        $result_query = mysqli_query($conn, $insert_details);
        if($result_query){
            echo "<script>alert('successfully added the quote request')</script>";
            echo "<script>window.open('Moving Price.php')</script>";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }
}
?>
