function login(e) {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
  
    if (username && password) {
      alert(`Welcome ${username}`)
      window.location.href = "./index.html";
    } else {
      alert("Please enter email and password");
    }
  }