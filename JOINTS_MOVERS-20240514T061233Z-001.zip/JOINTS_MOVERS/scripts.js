function sendMail(e) {
    e.preventDefault(); // Prevent form submission
    const userName = document.getElementById('name').value;
    const userEmail = document.getElementById('email').value;
    const service = document.getElementById('service').value;
    const address = document.getElementById('phone').value;
    const form = document.getElementById('form');
  
    console.log(userName, userEmail);
  
    let params = {
      username: userName,
      useremail: userEmail,
      service: service,
      from: document.getElementById('from').value,
      to: document.getElementById('to').value,
      date: document.getElementById('date').value,
      size: document.getElementById('size').value,
      phone: address,
    }
  
    console.log(params);
  
  
    if (service === "House Moving" || service === "Office Moving") {
      emailjs.send('service_1y7qjal', 'template_vixk9wv', params)
    .then(
      function(response) {
        console.log("Order sent!", response);
        alert("Order sent!");
        form.reset();
      },
      function(error) {
        alert("Error! Try again!");
        console.error("Failed to send order:", error);
      }
    )
    } else {
      emailjs.send('service_1y7qjal', 'template_y85wf6q', params)
    .then(
      function(response) {
        alert("Order sent!");
        form.reset();
      },
      function(error) {
        alert("Error! Try again!");
        console.error("Failed to send order:", error);
      }
    )
  
    }
  
  
  }