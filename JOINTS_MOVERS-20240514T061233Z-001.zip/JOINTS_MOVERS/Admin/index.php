<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JOINT MOVERS </title>
    <link rel="stylesheet" href="../Joint.css">
    <link rel="stylesheet" href="../responsive.css">

</head>
<body>
    <header>
        <!-- haeder start -->
        <div class="company-name"> 
            <div><img class="logo" src="../Joints/logo.jpg" ></div>
            <h1  style="margin-left: 30px;">JOINT MOVERS KENYA</h1>
            <li style="margin-left: 600px;color: blue;"><a href="login.php"> <b> Login</b></a></li>
    </div>
        
       

    </header>
    <!-- header end -->

    <!-- section start -->
    <Section class="header">
         <!-- nav start -->
         <nav>
            <div class="primary-nav">
                <ul class="nav">
                    <li><a href="index.php"><b>HOME</b></a></li>
                    <li><a href="users.php"><b>USERS</b></a></li>
                    <li><a href="admin.php"><b>USERS_ADMIN</b></a></li>
                    <li><a href="quote_request.php"><b>QUOTE REQUEST</b></a></li>
                   >
                   
                </ul>
            </div>
 </nav> 
 <h2 style="text-align: center;">ADMIN</h2>
 
 <!-- nav end -->

    </Section>
    <section class="body">
        <div class="home-img"><img src="../Joints/movers.jpg" alt=""></div>
        <div style=" margin-left: 50px;">
         <p style="color: red; font-weight: bold; font-size: xx-large;float: left;">Welcome to JOINT MOVERS
            Your Trusted Moving Company in Kenya.
            We Move you without stress</p>
            </div>
    </section>
    <section class="blocks">
        <div>
            <h4> <strong>About Us</strong></h4>
            <p>JOINTT Movers kenya offfers you unparalleled <br> service build on trust and backed at every level by <br>
                professional and experienced personnel.our high profile <br> credentials are built on provinging a professional, efficient <br>
                 and cost effective.</p>
        </div>
        <div style="margin-left: 150px;">
            <h4><strong>Our Locatio</strong></h4>
            <b> Location: </b><br>
            <p>Nairobi kenya</p>

        </div>
        <div style="margin-left: 250px;">
            <h4>Contact Us</h4>
            <p>
                <b> Telephone/EMAIL:</b> <br>
                +254797641465  <br>
                jointkenyamovers@gmail.com
             </p>    
        </div>
    </section>
            
    </section>
    <!-- section end-->
    <footer>
        <div style="margin-right: 5px;">
            <img class="logo" src="../Joints/logo.jpg" alt="">
        </div>
        <div>
            <h3>JOINT MOVERS</h3>
            <p>We Understand That Every Move Starts With A Detailed Assessment Of Your Requirements And Nature Of Your Goods</p>
        </div>
    </footer>
</body>
</html>