<?php
//connection parameters
$conn = mysqli_connect('localhost', 'root', '', 'users');

// Check connection
if ($conn) {
   echo "";
} else {
   // Use mysqli_connect_error() to get detailed error message
   die("Connection failed: " . mysqli_connect_error());
}
?>

